using System.Text.Json;

public class JsonRepository<T>
{
    private readonly string _filePath;

    public JsonRepository(string fileName)
    {
        string directory = "Datos";
        if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
        _filePath = Path.Combine(directory, fileName);
    }

    public void Save(List<T> data)
    {
        string json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_filePath, json);
    }

    public List<T> Load()
    {
        if (!File.Exists(_filePath)) return new List<T>();
        string json = File.ReadAllText(_filePath);
        return JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();
    }
}
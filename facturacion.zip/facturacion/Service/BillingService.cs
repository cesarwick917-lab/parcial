public class BillingService
{
    private List<Product> _products;
    private List<Invoice> _invoices;
    private readonly JsonRepository<Product> _productRepo;
    private readonly JsonRepository<Invoice> _invoiceRepo;

    public BillingService()
    {
        _productRepo = new JsonRepository<Product>("productos.json");
        _invoiceRepo = new JsonRepository<Invoice>("facturas.json");
        _products = _productRepo.Load();
        _invoices = _invoiceRepo.Load();
    }

    public List<Product> GetProducts() => _products;
    public List<Invoice> GetInvoices() => _invoices;

    public void AddProduct(Product product) => _products.Add(product);
    
    public void AddInvoice(Invoice invoice)
    {
        invoice.Number = _invoices.Count + 1;
        invoice.Date = DateTime.Now;
        _invoices.Add(invoice);
    }

    public void SaveChanges()
    {
        _productRepo.Save(_products);
        _invoiceRepo.Save(_invoices);
    }

    public Product FindProductByCode(string code) => _products.FirstOrDefault(p => p.Code == code);
}
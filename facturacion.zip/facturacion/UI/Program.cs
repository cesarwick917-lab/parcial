﻿namespace UI;
class Program
{
    static void Main()
    {
        new ConsoleInterface().Run();
    }
}
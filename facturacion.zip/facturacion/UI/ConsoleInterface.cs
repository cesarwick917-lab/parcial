public class ConsoleInterface
{
    private readonly BillingService _service = new BillingService();

    public void Run()
    {
        int option;
        do
        {
            ShowMenu();
            if (!int.TryParse(Console.ReadLine(), out option)) continue;

            switch (option)
            {
                case 1: CreateProduct(); break;
                case 2: ListProducts(); break;
                case 3: CreateInvoice(); break;
                case 4: ListInvoices(); break;
                case 5: _service.SaveChanges(); Console.WriteLine("Datos guardados."); break;
            }
        } while (option != 5);
    }

    private void ShowMenu()
    {
        Console.WriteLine("\n--- SISTEMA DE FACTURACIÓN ---");
        Console.WriteLine("1. Registrar producto");
        Console.WriteLine("2. Listar productos");
        Console.WriteLine("3. Crear Factura");
        Console.WriteLine("4. Listar facturas");
        Console.WriteLine("5. Guardar y Salir");
        Console.Write("Seleccione una opción: ");
    }

    private void CreateProduct()
    {
        Console.Write("Código: ");
        string code = Console.ReadLine();
        Console.Write("Nombre: ");
        string name = Console.ReadLine();
        Console.Write("Precio: ");
        decimal price = decimal.Parse(Console.ReadLine());

        _service.AddProduct(new Product(code, name, price));
        Console.WriteLine("Producto registrado.");
    }

    private void ListProducts()
    {
        Console.WriteLine("\n--- PRODUCTOS ---");
        var products = _service.GetProducts();
        if (!products.Any()) Console.WriteLine("No hay productos.");
        else products.ForEach(p => Console.WriteLine(p));
    }

    private void CreateInvoice()
    {
        var products = _service.GetProducts();
        if (!products.Any()) { Console.WriteLine("No hay productos registrados."); return; }

        Invoice invoice = new Invoice();
        bool adding = true;

        while (adding)
        {
            ListProducts();
            Console.Write("Código del producto: ");
            string code = Console.ReadLine();
            Product product = _service.FindProductByCode(code);

            if (product != null)
            {
                Console.Write("Cantidad: ");
                int qty = int.Parse(Console.ReadLine());
                invoice.Details.Add(new InvoiceDetail(product, qty));
            }
            else Console.WriteLine("No encontrado.");

            Console.Write("¿Agregar otro? (s/n): ");
            adding = Console.ReadLine()?.ToLower() == "s";
        }

        _service.AddInvoice(invoice);
        ShowInvoiceSummary(invoice);
    }

    private void ShowInvoiceSummary(Invoice invoice)
    {
        Console.WriteLine("\n--- RESUMEN ---");
        foreach (var d in invoice.Details)
            Console.WriteLine($"{d.Product.Name} x{d.Quantity} = RD$ {d.SubTotal}");
        Console.WriteLine($"Subtotal: RD$ {invoice.SubTotal}");
        Console.WriteLine($"ITBIS: RD$ {invoice.TaxAmount}");
        Console.WriteLine($"Total: RD$ {invoice.Total}");
    }

    private void ListInvoices()
    {
        Console.WriteLine("\n--- HISTORIAL DE FACTURAS ---");
        var invoices = _service.GetInvoices();
        if (!invoices.Any()) Console.WriteLine("No hay facturas.");
        else invoices.ForEach(i => Console.WriteLine(i));
    }
}
public class Invoice
{
    public int Number { get; set; }
    public DateTime Date { get; set; }
    public List<InvoiceDetail> Details { get; set; } = new List<InvoiceDetail>();
    public const decimal TaxRate = 0.18m;

    public decimal SubTotal => Details.Sum(d => d.SubTotal);
    public decimal TaxAmount => SubTotal * TaxRate;
    public decimal Total => SubTotal + TaxAmount;

    public override string ToString() => $"Factura #{Number} - {Date:dd/MM/yyyy} - Total: RD$ {Total}";
}
public class InvoiceDetail
{
    public Product Product { get; set; }
    public int Quantity { get; set; }
    public decimal SubTotal => Product.Price * Quantity;

    public InvoiceDetail() { }

    public InvoiceDetail(Product product, int quantity)
    {
        Product = product;
        Quantity = quantity;
    }
}